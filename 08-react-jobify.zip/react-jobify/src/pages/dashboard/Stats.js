import React from 'react'

function Stats() {
  return <div>数据统计</div>
}

export default Stats
