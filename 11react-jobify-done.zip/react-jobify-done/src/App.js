import { Landing, Error, Register, ProtectedRoute } from "./pages";
import {
  AddJob,
  AllJobs,
  Stats,
  SharedLayout,
  Profile,
} from "./pages/dashboard";

import { BrowserRouter, Routes, Route } from "react-router-dom";
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/react/demo20/"
          element={
            <ProtectedRoute>
              <SharedLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Stats />} />
          <Route path="/react/demo20/all-jobs" element={<AllJobs />} />
          <Route path="/react/demo20/add-job" element={<AddJob />} />
          <Route path="/react/demo20/profile" element={<Profile />} />
        </Route>
        <Route path="/react/demo20/register" element={<Register />} />
        <Route path="/react/demo20/landing" element={<Landing />} />
        <Route path="/react/demo20/*" element={<Error />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
