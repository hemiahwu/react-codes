import { Landing, Error, Register, ProtectedRoute } from './pages'
import {
  AddJob,
  AllJobs,
  Stats,
  SharedLayout,
  Profile,
} from './pages/dashboard'

import { BrowserRouter, Routes, Route } from 'react-router-dom'
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/react-job"
          element={
            <ProtectedRoute>
              <SharedLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Stats />} />
          <Route path="/react-job/all-jobs" element={<AllJobs />} />
          <Route path="/react-job/add-job" element={<AddJob />} />
          <Route path="/react-job/profile" element={<Profile />} />
        </Route>
        <Route path="/react-job/register" element={<Register />} />
        <Route path="/react-job/landing" element={<Landing />} />
        <Route path="*" element={<Error />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
