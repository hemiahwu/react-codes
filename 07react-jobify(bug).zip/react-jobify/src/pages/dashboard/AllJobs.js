import React from 'react'

function AllJobs() {
  return <div>AllJobs</div>
}

export default AllJobs
