import React from 'react'

function Profile() {
  return <div>个人信息</div>
}

export default Profile
