import React from 'react'

function AddJob() {
  return <div>AddJob</div>
}

export default AddJob
