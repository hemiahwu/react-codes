import { useAppContext } from '../context/appContext'
import { useEffect } from 'react'
import Loading from './Loading'
import Wrapper from '../assets/wrappers/JobsContainer'
import Job from './Job'

const JobsContainer = () => {
  const { getJobs, isLoading, totalJobs, jobs } = useAppContext()

  useEffect(() => {
    getJobs()
  }, [])

  if (isLoading) {
    return <Loading center />
  }

  if (jobs.length === 0) {
    return (
      <Wrapper>
        <h2>没有任何工作展示</h2>
      </Wrapper>
    )
  }

  return (
    <Wrapper>
      <h5>共有 {totalJobs}个工作展示</h5>
      <div className="jobs">
        {jobs.map((job) => {
          return <Job key={job._id} {...job} />
        })}
      </div>
    </Wrapper>
  )
}

export default JobsContainer
