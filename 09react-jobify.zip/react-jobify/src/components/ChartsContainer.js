const ChartsContainer = () => {
  return <h1>图表容器</h1>
}

export default ChartsContainer
