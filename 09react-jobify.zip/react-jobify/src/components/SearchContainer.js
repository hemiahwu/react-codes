const SearchContainer = () => {
  return <h1>搜索组件</h1>
}

export default SearchContainer
