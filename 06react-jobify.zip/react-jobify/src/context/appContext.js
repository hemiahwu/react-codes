import React, { useContext, useReducer } from 'react'
import {
  DISPLAY_ALERT,
  CLEAR_ALERT,
  REGISTER_USER_BEGIN,
  REGISTER_USER_ERROR,
  REGISTER_USER_SUCCESS,
} from './actions'
import reducer from './reducer'
import axios from 'axios'

const initialState = {
  isLoading: false,
  showAlert: false,
  alertText: '',
  alertType: '',
  user: null,
  token: null,
  userLocation: '',
}

const AppContext = React.createContext()

const AppProvider = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState)

  // 派发"弹窗"任务
  const displayAlert = () => {
    dispatch({ type: DISPLAY_ALERT })
    clearAlert()
  }

  const clearAlert = () => {
    setTimeout(() => dispatch({ type: CLEAR_ALERT }), 3000)
  }

  // 派发注册事件
  const registerUser = async (currentUser) => {
    // console.log(currentUser)
    dispatch({ type: REGISTER_USER_BEGIN })
    // 请求注册接口
    try {
      const response = await axios.post(
        '/api/v1/react-job/auth/register',
        currentUser,
      )
      // console.log(response)
      const { user, token, location } = response.data

      dispatch({
        type: REGISTER_USER_SUCCESS,
        payload: { user, token, location },
      })
    } catch (error) {
      console.log(error.response.data)
      dispatch({
        type: REGISTER_USER_ERROR,
        payload: { msg: error.response.data.msg },
      })
    }

    clearAlert()
  }

  return (
    <AppContext.Provider value={{ ...state, displayAlert, registerUser }}>
      {children}
    </AppContext.Provider>
  )
}

const useAppContext = () => {
  return useContext(AppContext)
}

export { AppProvider, useAppContext }
