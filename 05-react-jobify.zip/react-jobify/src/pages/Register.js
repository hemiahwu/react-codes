import React, { useState } from 'react'
import { Logo, FormRow, Alert } from '../components'
import Wrapper from '../assets/wrappers/RegisterPage'

const initialState = {
  name: '',
  email: '',
  password: '',
  isMember: true,
  showAlert: false,
}

function Register() {
  const [values, setValues] = useState(initialState)

  const onSubmit = (e) => {
    e.preventDefault()
  }

  const handleChange = (e) => {
    console.log(e.target.name, e.target.value)
    setValues({ ...values, [e.target.name]: e.target.value })
  }

  const toggleMember = () => {
    setValues({ ...values, isMember: !values.isMember })
  }

  return (
    <Wrapper className="full-page">
      <form onSubmit={onSubmit} className="form">
        <Logo />
        <h3>{!values.isMember ? '注册' : '登录'}</h3>
        {/* 弹窗 */}
        {values.showAlert && <Alert />}
        {/* name */}
        {!values.isMember && (
          <FormRow
            type="text"
            name="name"
            value={values.name}
            handleChange={handleChange}
          />
        )}
        {/* email */}
        <FormRow
          type="email"
          name="email"
          value={values.email}
          handleChange={handleChange}
        />
        {/* password */}
        <FormRow
          type="password"
          name="password"
          value={values.password}
          handleChange={handleChange}
        />
        <button type="submit" className="btn btn-block">
          提交
        </button>

        <p>
          {values.isMember ? '没有账号?' : '已有账号?'}
          <button className="member-btn" onClick={toggleMember}>
            {values.isMember ? '注册' : '登录'}
          </button>
        </p>
      </form>
    </Wrapper>
  )
}

export default Register
