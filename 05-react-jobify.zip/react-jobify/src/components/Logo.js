import logo from '../assets/images/logo.svg'

function Logo() {
  return <img src={logo} alt="logo" />
}

export default Logo
