import React from 'react'

function Alert() {
  return <div className="alert alert-danger">Alert</div>
}

export default Alert
